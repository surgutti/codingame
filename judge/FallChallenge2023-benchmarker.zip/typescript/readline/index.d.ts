declare function readline(): string
