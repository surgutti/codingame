interface Window {
  debug: any
}
